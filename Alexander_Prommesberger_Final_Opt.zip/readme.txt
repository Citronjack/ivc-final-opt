% ------------------------------------------------------------------- Read Me ------------------------------------------------------------------------
% To Run the Code
% 
% 0. Open Alexander_Prommesberger_FinalOpt.m
% 1. Select the path to your images and add myfunctions, IVC Huffman and Data for plot folders to path!
% 2. Press Run to run with default Parameters --> only 8x8 Prediction is used! h_fac  =5; qScales = [0.07, 0.2, 0.4, 0.8, 1.0, 1.5, 2, 3, 4.1, 4.5];
% 3. Play arount with the parameters, describtion in Alexander_Prommesberger_FinalOpt.m
	- If 4x4 PRed should be used: h_fac = 1.05 is recommended --> qScale should be below 0.5! for ex. qScales = [0.07, 0.2, 0.4];
	- EOB should not be under 4000, could raise decoding problems!
    - max_displacement=4 is good value, if lower, bpp could raise, run time problems if to high !
%
%
%
% To Plot the Curves:
% 0. Go into Data for Plot and run PlotSkript_FinalResults
%
%
% Presentation:
% 0. Go into Presentation and open the mp4 file (Volumne adjustments might be necessary!)
%
%
%
%
%
%
